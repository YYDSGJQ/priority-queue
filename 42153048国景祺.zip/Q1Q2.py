import random
from graphviz import Digraph
import time



class Node:
    def __init__(self,key=None,next=None):
        self.key=key
        self.next=next

class btree:
    def __init__(self,root=None):
        self.root = root

    def push(self,node:Node):
        if self.root:
            p=self.root
            n=p.next
            while n:
                p=n
                n=n.next
            p.next=node
        else:
            self.root = node

    def getNodeidx(self,node):
        n=self.root
        idx=0
        while node != n:
            idx = idx +1
            n=n.next
        if n==None:
            return -1
        return idx

    def getidx(self,index):
        if index<0:
            raise ValueError(f"index should >= 0, but get {index}")
        node = self.root
        for i in range(index):
            if node.next:
                node=node.next
            else:
                return None
        return node

    def getParentbyIdx(self, index:int):
        if index<=0:
            return None

        pindex = int((index - 1) / 2)
        p=self.getidx(pindex)
        return p

    def getlchildbyIdx(self, index:int):
        if index<0:
            raise ValueError(f"[getChild]index should >= 0, but get {index}")
        cindex = index * 2 + 1
        p=self.getidx(cindex)
        return p

    def getrchildbyIdx(self, index:int):
        if index<0:
            raise ValueError(f"[getChild]index should >= 0, but get {index}")
        cindex = index * 2 + 2
        p = self.getidx(cindex)
        return p

class minPriorQueue(btree):
    def __init__(self,root=None):
        super(minPriorQueue, self).__init__(root)

    def insert(self,node:Node):
        self.push(node)

        idx = self.getNodeidx(node)

        n = self.getidx(idx)
        p = self.getParentbyIdx(idx)

        # up update
        while idx>0 and n.key<p.key:
            # exchange
            temp = p.key
            p.key=n.key
            n.key=temp
            idx = int((idx - 1) / 2)
            n = p
            p = self.getParentbyIdx(idx)



    def delMin(self):
        # del the tail
        p=self.root
        n=p.next
        while n.next:
            p=n
            n=n.next
        p.next=None
        self.root.key=n.key

        # down update

        idx=0
        n=self.root

        while n:
            l = self.getlchildbyIdx(idx)
            r = self.getrchildbyIdx(idx)
            if l and r:
                if l.key<r.key:
                    temp = n.key
                    n.key = l.key
                    l.key = temp
                    n = l
                    idx = idx * 2 + 1
                    continue
                else:
                    temp = n.key
                    n.key = r.key
                    r.key = temp
                    n = r
                    idx = idx * 2 + 2
                    continue
            elif l:
                temp = n.key
                n.key = l.key
                l.key = temp
                n = l
                idx = idx * 2 + 1
                continue
            else:
                n=None

    def viz(self):
        graph = Digraph(comment='The min Prior Queue based on binary tree')
        p = self.root
        idx = 0
        graph.node(f'{idx}', str(p.key))
        while p:
            l = self.getlchildbyIdx(idx)
            r = self.getrchildbyIdx(idx)
            if l:
                lidx = idx * 2 + 1
                graph.node(f'{lidx}', str(l.key))
                graph.edge(f'{idx}', f'{lidx}')

                if r:
                    ridx = idx * 2 + 2
                    graph.node(f'{ridx}', str(r.key))
                    graph.edge(f'{idx}', f'{ridx}')
                    p=p.next
                    idx=idx+1
                    continue
            break
        t=round(time.time(),2)
        graph.view(f"{t}.gv")






