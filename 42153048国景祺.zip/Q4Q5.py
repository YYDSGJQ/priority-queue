import random
from myStruct import *
import matplotlib.pyplot as plt

if __name__ == '__main__':

    # Q1
    length = 10
    root = Node(key=random.randint(0, 100))
    T=btree(root=root)
    for i in range(1,length):
        n=Node(key=random.randint(0, 100))
        T.push(n)

    print("idx 1 has parent:",T.getNodeidx(T.getParentbyIdx(1)))  # should be 0
    print("idx 2 has parent:",T.getNodeidx(T.getParentbyIdx(2)))  # should be 0
    print("idx 1 has left child:",T.getNodeidx(T.getlchildbyIdx(1)))  # should be 3
    print("idx 1 has right child:",T.getNodeidx(T.getrchildbyIdx(1)))  # should be 4


    # Q2
    length = 20
    root = Node(key=random.randint(0, 100))
    T=minPriorQueue(root=root)
    timelist=[]
    t1 = time.time()
    for i in range(1,length):
        n=Node(key=random.randint(0, 100))
        T.insert(n)
        t2=time.time()
        t=(t2-t1)*1000
        timelist.append(t)

    # visualize the performence
    # step = range(1,length)
    # plt.plot(step, timelist, color="red")
    # plt.xlabel("insert num")
    # plt.ylabel("time(ms)")
    # plt.title("Insert time")
    # # plt.show()  # 画图
    # plt.savefig("inserttime.jpg")

    # visualize and delMin()
    T.viz()
    T.delMin()
    T.viz()